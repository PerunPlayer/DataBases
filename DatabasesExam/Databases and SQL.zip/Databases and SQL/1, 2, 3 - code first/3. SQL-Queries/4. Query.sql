SELECT Superhero FROM SuperheroUniverse
WHERE SuperheroId = 11
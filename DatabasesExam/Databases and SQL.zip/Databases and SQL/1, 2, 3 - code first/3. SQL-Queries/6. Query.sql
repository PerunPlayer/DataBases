SELECT Fraction FROM SuperheroUniverse
WHERE FractionId = 17
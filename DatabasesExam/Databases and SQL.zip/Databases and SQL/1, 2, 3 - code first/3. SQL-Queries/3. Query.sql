SELECT Superhero FROM SuperheroUniverse
WHERE City IS [New York]
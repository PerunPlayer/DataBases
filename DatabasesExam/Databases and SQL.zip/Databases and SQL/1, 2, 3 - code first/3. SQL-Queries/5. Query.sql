SELECT Fraction FROM SuperheroUniverse

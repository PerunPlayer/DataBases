SELECT Superheroes FROM SuperheroesUniverse
WHERE Power  IS [Martial arts]
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperheroesUniverse.Queries
{
    public class Program
    {
        public static void Main()
        {
            
        }
    }
}

﻿namespace SuperHeroes.Models
{
    public enum AligmentType
    {
        Good = 0,
        Evil = 1,
        Neutral = 2
    }
}
